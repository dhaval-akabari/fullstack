require("./bootstrap");

import { createApp } from "vue";
import router from "./router";
import common from "./common";
import Toaster from "@meforma/vue-toaster";

import store from './store';

import App from "./App.vue";

const app = createApp(App);

app.mixin(common);
app.use(router);
app.use(store);
app.use(Toaster, {
    position: "top-right",
    duration: 3000,
});

app.mount("#app");
